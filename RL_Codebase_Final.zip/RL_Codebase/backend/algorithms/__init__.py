"""Algorithms package.

Algorithms are selected by string name and instantiated via AlgorithmFactory.
This keeps the Flask API algorithm-agnostic and makes it easy to add new
algorithms later (e.g., SARSA, DQN wrappers).

Phase 1: Tabular Q-Learning.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Type

from .base_algorithm import BaseAlgorithm
from .q_learning import QLearning


class AlgorithmFactory:
    """Factory for creating algorithm instances and exposing metadata."""

    _ALGORITHMS: Dict[str, Type[BaseAlgorithm]] = {
        'Q-Learning': QLearning,
    }

    @classmethod
    def get_available_algorithms(cls) -> List[str]:
        """Return a list of algorithm names supported by the backend."""
        return list(cls._ALGORITHMS.keys())

    @classmethod
    def create_algorithm(cls, name: str, env, parameters: Dict[str, Any]) -> BaseAlgorithm:
        """Instantiate an algorithm by name.

        Args:
            name: Algorithm display name (e.g., 'Q-Learning')
            env: Gymnasium environment instance
            parameters: Parameter dict from the frontend

        Raises:
            ValueError: if the algorithm name is unknown
        """
        if name not in cls._ALGORITHMS:
            raise ValueError(
                f"Algorithm '{name}' not supported. Available algorithms: {cls.get_available_algorithms()}"
            )
        return cls._ALGORITHMS[name](env, parameters)

    @classmethod
    def get_parameter_schema(cls, name: str, environment: Optional[str] = None) -> Dict[str, Dict[str, Any]]:
        """Return the parameter schema for the given algorithm."""
        if name not in cls._ALGORITHMS:
            raise ValueError(
                f"Algorithm '{name}' not supported. Available algorithms: {cls.get_available_algorithms()}"
            )
        algorithm_cls = cls._ALGORITHMS[name]
        return algorithm_cls.get_parameter_schema(environment)

"""Small command-line demo to verify the code is runnable without the frontend.

This script trains Q-Learning on FrozenLake and prints a simple success rate.

Usage (from RL_Codebase root):
  python -m venv .venv && source .venv/bin/activate
  pip install -r requirements.txt
  python backend/run_demo.py
"""

from __future__ import annotations

import argparse

from algorithms import AlgorithmFactory
from environments.environment_manager import EnvironmentManager


def evaluate_policy(algorithm, episodes: int = 100) -> float:
    """Run greedy policy for N episodes and return success rate."""
    successes = 0
    for _ in range(episodes):
        state, _ = algorithm.env.reset()
        done = False
        steps = 0
        while not done and steps < 100:
            # Greedy action (ties broken randomly by algorithm helper)
            action = algorithm._argmax_random_tiebreak(algorithm.q_table[state])
            state, reward, terminated, truncated, _ = algorithm.env.step(action)
            done = terminated or truncated
            successes += int(reward)
            steps += 1
    return successes / episodes


def main() -> None:
    parser = argparse.ArgumentParser(description='Q-Learning FrozenLake demo')
    parser.add_argument('--env', default='FrozenLake-v1-NoSlip', choices=EnvironmentManager.get_available_environments())
    parser.add_argument('--episodes', type=int, default=500)
    parser.add_argument('--eval-episodes', type=int, default=200)
    parser.add_argument('--alpha', type=float, default=0.1)
    parser.add_argument('--gamma', type=float, default=0.95)
    parser.add_argument('--epsilon', type=float, default=0.1)
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()

    env = EnvironmentManager.create_environment(args.env, seed=args.seed)

    params = {
        'learning_rate': args.alpha,
        'discount_factor': args.gamma,
        'exploration_rate': args.epsilon,
        'num_episodes': args.episodes,
    }

    algo = AlgorithmFactory.create_algorithm('Q-Learning', env, params)

    algo.train(args.episodes)
    success_rate = evaluate_policy(algo, episodes=args.eval_episodes)

    print(f"Environment: {args.env}")
    print(f"Trained episodes: {args.episodes}")
    print(f"Evaluation episodes: {args.eval_episodes}")
    print(f"Success rate: {success_rate:.2%}")

    env.close()


if __name__ == '__main__':
    main()

"""Training/session management package."""

from .trainer import TrainingCoordinator

__all__ = ["TrainingCoordinator"]

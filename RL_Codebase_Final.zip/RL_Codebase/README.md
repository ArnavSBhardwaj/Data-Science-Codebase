RL_Codebase (Q-Learning on FrozenLake)

This submission contains a small, structured Python project implementing tabular
Q-Learning for Gymnasium FrozenLake, plus example notebooks.

Folder structure

- backend/
  - app.py                     Flask API (used by the React UI / Docker demo)
  - algorithms/
    - base_algorithm.py         Interface (Separation of Concerns)
    - q_learning.py             Tabular Q-Learning implementation
    - __init__.py               AlgorithmFactory (select algorithm by name)
  - environments/
    - environment_manager.py    Environment creation + frame conversion
  - training/
    - trainer.py                TrainingCoordinator (sessions, training, playback)
- examples/
  - frozenlake_q_learning.ipynb
  - solution_frozenlake_q_learning.ipynb

How to run (local Python)

1) Create and activate a virtual environment (recommended)

   python -m venv .venv
   source .venv/bin/activate

2) Install dependencies

   pip install -r requirements.txt

3) Start backend

   cd backend
   python app.py

Backend runs at http://localhost:5001

Notes

- The backend exposes REST endpoints to start training and SSE endpoints to
  stream training updates/frames.
- Q-Learning is implemented in backend/algorithms/q_learning.py and can be read
  standalone for the update rule and epsilon-greedy policy.
